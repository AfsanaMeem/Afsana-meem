import { Mystery } from './mystery';

describe('Mystery', () => {
  it('should create an instance', () => {
    expect(new Mystery()).toBeTruthy();
  });
});
