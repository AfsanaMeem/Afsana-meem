export class Mystery {
    number:any;
    name:any;
    writer:any;
    image:any;
    stock:any;
    categoryname:any;
    bookshelf:any;
   

    constructor(number:any,name:any,writer:any,image:any,stock:any,categoryname:any,bookshelf:any){
        this.number=number;
        this.name=name;
        this.writer=writer;
        this.image=image;
        this.stock=stock;
        this.categoryname=categoryname;
        this.bookshelf=bookshelf;
    }
}