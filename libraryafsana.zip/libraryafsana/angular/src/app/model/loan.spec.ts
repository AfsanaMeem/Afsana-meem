import { Loan } from './loan';

describe('Loan', () => {
  it('should create an instance', () => {
    expect(new Loan()).toBeTruthy();
  });
});
