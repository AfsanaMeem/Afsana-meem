export class Categorie {
    id:any;
    name:any;
    images:any;
    description:any;
   

    constructor(id:any,name:any,images:any,description:any){
        this.id=id;
        this.name=name;
        this.images=images;
        this.description=description;
        
    }
}
