export class Loan {
    number:any;
    username:any;
    userid:any;
    bookname:any;
    booknumber:any;
    image:any;
    categoryname:any;
    bookshelf:any;

    
    constructor(number:any,username:any,userid:any,bookname:any,booknumber:any,image:any,categoryname:any,bookshelf:any){
        this.number=number;
        this.username=username;
        this.userid=userid;
        this.bookname=bookname;
        this.booknumber=booknumber;
        this.image=image;
        this.categoryname=categoryname;
        this.bookshelf=bookshelf;
    }
}
