export class Admin {
    id:any;
    name:any;
    email:any;
    password:any;
    address:any;
    phone:any;
    gender:any;

    constructor(id:any,name:any,email:any,password:any,address:any,phone:any,gender:any){
        this.id=id;
        this.name=name;
        this.email=email;
        this.password=password;
        this.address=address;
        this.phone=phone;
        this.gender=gender;
    }
}