import { Categorie } from './categorie';

describe('Categorie', () => {
  it('should create an instance', () => {
    expect(new Categorie()).toBeTruthy();
  });
});
